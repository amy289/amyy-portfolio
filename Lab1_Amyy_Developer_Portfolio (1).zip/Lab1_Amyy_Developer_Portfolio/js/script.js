// Shared interactions for Amyy's portfolio.
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.year').forEach((item) => { item.textContent = new Date().getFullYear(); });

  const menuButton = document.querySelector('.menu-toggle');
  const navigation = document.querySelector('.nav-links');
  if (menuButton && navigation) {
    menuButton.addEventListener('click', () => {
      const isOpen = navigation.classList.toggle('open');
      menuButton.setAttribute('aria-expanded', String(isOpen));
    });
  }

  const themeButtons = document.querySelectorAll('.theme-toggle');
  const savedTheme = localStorage.getItem('amyy-portfolio-theme');
  if (savedTheme === 'dark') document.body.classList.add('dark-theme');
  themeButtons.forEach((button) => {
    button.textContent = document.body.classList.contains('dark-theme') ? '☀' : '☾';
    button.addEventListener('click', () => {
      document.body.classList.toggle('dark-theme');
      const dark = document.body.classList.contains('dark-theme');
      localStorage.setItem('amyy-portfolio-theme', dark ? 'dark' : 'light');
      themeButtons.forEach((item) => { item.textContent = dark ? '☀' : '☾'; });
    });
  });

  const contactForm = document.querySelector('#contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', (event) => {
      event.preventDefault();
      if (!contactForm.checkValidity()) {
        contactForm.reportValidity();
        return;
      }
      document.querySelector('#form-message').textContent = 'Thank you! Your form is valid. This demo does not send messages to a server.';
      contactForm.reset();
    });
  }
});
